# Controle PS2 virtual para Android (teste)

Projeto Android de teste, compilável pelo workflow do GitHub Actions. Ele lista apps com ícone de inicialização, oferece controle flutuante editável por arraste e captura teclas comuns de gamepads Bluetooth via AccessibilityService.

## Limites importantes
- Ative a permissão de sobreposição e, se desejar encaminhar comandos, habilite o serviço de acessibilidade do app nas Configurações do Android.
- Android restringe injeção de toques; jogos podem ignorar os comandos, bloquear overlays ou exigir suporte próprio a gamepad.
- O gamepad é mapeado como toques repetidos, não como um controle HID universal; analógicos e pressão analógica variam por aparelho e jogo.
- O app abre jogos pelo lançador do Android, mas não consegue forçar que outro jogo mude sua orientação. A tela do painel é horizontal; o jogo pode impor retrato ou sua própria orientação.
- A edição atual permite mover botões flutuantes. É um protótipo para teste, sem garantia de compatibilidade com todos os jogos.

## APK pelo GitHub
1. Envie os arquivos para um repositório GitHub com a pasta `ps2-controller-android` e `.github/workflows/android.yml` na raiz.
2. Abra **Actions** e execute **Build APK** (ou faça push na branch principal).
3. Baixe o artefato `controle-ps2-apk-debug` na execução concluída e instale o APK no Android.

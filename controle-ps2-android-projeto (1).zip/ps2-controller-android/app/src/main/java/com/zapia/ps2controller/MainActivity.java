package com.zapia.ps2controller;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.content.pm.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout root, list;
    private TextView status;
    private final int bg=Color.rgb(18,22,32), panel=Color.rgb(31,39,55), blue=Color.rgb(42,105,158);
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().getDecorView().setSystemUiVisibility(5894|1024|512|4096); showHome();}
    private TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);t.setPadding(8,8,8,8);return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));return b;}
    private void showHome(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(20,14,20,12);root.setBackgroundColor(bg);setContentView(root);
        TextView title=text("CONTROLE VIRTUAL • ESTILO PS2",22);root.addView(title);
        root.addView(text("Escolha um jogo instalado que apareça no lançador do Android. Pareie o controle nas configurações Bluetooth do aparelho.",14));
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
        Button overlay=button("1 • Permitir controles flutuantes");overlay.setOnClickListener(v->{if(!Settings.canDrawOverlays(this))startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));else status.setText("Permissão de sobreposição já concedida.");});actions.addView(overlay,new LinearLayout.LayoutParams(0,-2,1));
        Button access=button("2 • Ativar acessibilidade");access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));actions.addView(access,new LinearLayout.LayoutParams(0,-2,1));root.addView(actions);
        Button start=button("Mostrar controles flutuantes");start.setOnClickListener(v->{if(!Settings.canDrawOverlays(this)){status.setText("Conceda primeiro a permissão de sobreposição.");return;}startService(new Intent(this,FloatingControllerService.class));status.setText("Controles ativos. Ative o serviço de acessibilidade para encaminhar toques ao jogo.");});root.addView(start);
        status=text("Para sair do painel e voltar aqui, toque no ícone do app.",13);root.addView(status);
        root.addView(text("JOGOS INSTALADOS",18));ScrollView scroll=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);scroll.addView(list);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));loadApps();
    }
    private void loadApps(){
        PackageManager pm=getPackageManager();Intent query=new Intent(Intent.ACTION_MAIN,null);query.addCategory(Intent.CATEGORY_LAUNCHER);List<ResolveInfo> apps=pm.queryIntentActivities(query,0);
        Collections.sort(apps,(a,b)->String.CASE_INSENSITIVE_ORDER.compare(a.loadLabel(pm).toString(),b.loadLabel(pm).toString()));
        for(ResolveInfo ri:apps){String pkg=ri.activityInfo.packageName;if(pkg.equals(getPackageName()))continue;String label=ri.loadLabel(pm).toString();Button row=button("▶  "+label);row.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);row.setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel));row.setOnClickListener(v->{Intent launch=pm.getLaunchIntentForPackage(pkg);if(launch!=null){try{startActivity(launch);status.setText("Aberto: "+label+". Se necessário, ative o controle flutuante antes de abrir o jogo.");}catch(Exception ex){status.setText("Não foi possível abrir esse jogo.");}}});list.addView(row,new LinearLayout.LayoutParams(-1,-2));}
        if(apps.isEmpty())list.addView(text("Nenhum app lançável foi encontrado.",14));
    }
}

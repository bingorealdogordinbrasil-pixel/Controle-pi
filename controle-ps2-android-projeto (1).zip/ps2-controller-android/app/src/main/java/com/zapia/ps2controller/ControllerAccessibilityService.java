package com.zapia.ps2controller;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import android.os.Handler;
import android.os.Looper;
import java.util.*;

public class ControllerAccessibilityService extends AccessibilityService {
    public static ControllerAccessibilityService instance;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Set<Integer> held=new HashSet<>();
    @Override public void onServiceConnected(){instance=this;}
    @Override public void onAccessibilityEvent(AccessibilityEvent e){}
    @Override public void onInterrupt(){held.clear();}
    @Override public boolean onKeyEvent(KeyEvent e){int code=e.getKeyCode();int mapped=map(code);if(mapped<0)return false;if(e.getAction()==KeyEvent.ACTION_DOWN){if(held.add(code))repeatTap(mapped,code);}else if(e.getAction()==KeyEvent.ACTION_UP){held.remove(code);}return true;}
    private void repeatTap(int index,int key){if(!held.contains(key))return; FloatingControllerService.tapMapped(index);handler.postDelayed(()->repeatTap(index,key),145);}
    private int map(int k){switch(k){case KeyEvent.KEYCODE_BUTTON_A:return 0;case KeyEvent.KEYCODE_BUTTON_B:return 1;case KeyEvent.KEYCODE_BUTTON_X:return 2;case KeyEvent.KEYCODE_BUTTON_Y:return 3;case KeyEvent.KEYCODE_BUTTON_L1:return 4;case KeyEvent.KEYCODE_BUTTON_R1:return 5;case KeyEvent.KEYCODE_BUTTON_SELECT:return 6;case KeyEvent.KEYCODE_BUTTON_START:return 7;case KeyEvent.KEYCODE_DPAD_UP:return 8;case KeyEvent.KEYCODE_DPAD_DOWN:return 9;case KeyEvent.KEYCODE_DPAD_LEFT:return 10;case KeyEvent.KEYCODE_DPAD_RIGHT:return 11;default:return -1;}}
    public void tap(float x,float y){if(android.os.Build.VERSION.SDK_INT<24)return;Path p=new Path();p.moveTo(x,y);GestureDescription.StrokeDescription s=new GestureDescription.StrokeDescription(p,0,55);dispatchGesture(new GestureDescription.Builder().addStroke(s).build(),null,null);}
}

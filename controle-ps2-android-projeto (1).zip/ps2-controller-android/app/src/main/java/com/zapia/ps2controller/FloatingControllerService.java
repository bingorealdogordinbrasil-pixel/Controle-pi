package com.zapia.ps2controller;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class FloatingControllerService extends Service {
    static FloatingControllerService instance;
    WindowManager wm; FrameLayout layer; boolean editing=false; float alpha=.78f;
    final String[] names={"×","○","□","△","L1","R1","SELECT","START","▲","▼","◀","▶"};
    final int[] ids={0,1,2,3,4,5,6,7,8,9,10,11};
    @Override public void onCreate(){super.onCreate();instance=this;wm=(WindowManager)getSystemService(WINDOW_SERVICE);createNotification();build();}
    private void createNotification(){if(Build.VERSION.SDK_INT>=26){NotificationManager nm=getSystemService(NotificationManager.class);nm.createNotificationChannel(new NotificationChannel("controller","Controle flutuante",NotificationManager.IMPORTANCE_LOW));Notification n=new Notification.Builder(this,"controller").setContentTitle("Controle virtual ativo").setContentText("Toque para voltar às opções do controle").setSmallIcon(android.R.drawable.ic_media_play).build();startForeground(41,n);}}
    private WindowManager.LayoutParams params(){return new WindowManager.LayoutParams(-1,-1,Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT);}
    private void build(){layer=new FrameLayout(this);layer.setBackgroundColor(Color.TRANSPARENT);addButton("⚙",.50f,.08f,-1,true);addButton("▲",.12f,.60f,8,false);addButton("▼",.12f,.83f,9,false);addButton("◀",.065f,.715f,10,false);addButton("▶",.175f,.715f,11,false);addButton("△",.88f,.57f,3,false);addButton("○",.94f,.69f,1,false);addButton("×",.82f,.79f,0,false);addButton("□",.76f,.67f,2,false);addButton("L1",.08f,.16f,4,false);addButton("L2",.08f,.08f,4,false);addButton("R1",.92f,.16f,5,false);addButton("R2",.92f,.08f,5,false);addButton("SELECT",.44f,.44f,6,false);addButton("START",.56f,.44f,7,false);try{wm.addView(layer,params());}catch(Exception ignored){}}
    private void addButton(String label,float px,float py,int action,boolean menu){TextView b=new TextView(this);b.setTag(action);b.setText(label);b.setTextColor(Color.WHITE);b.setTextSize(label.length()>2?12:20);b.setGravity(Gravity.CENTER);b.setBackground(makeBg());b.setAlpha(alpha);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(label.length()>2?62:58),dp(label.length()>2?38:58));lp.leftMargin=(int)(getResources().getDisplayMetrics().widthPixels*px)-dp(label.length()>2?31:29);lp.topMargin=(int)(getResources().getDisplayMetrics().heightPixels*py)-dp(label.length()>2?19:29);layer.addView(b,lp);
        b.setOnTouchListener(new View.OnTouchListener(){float sx,sy,ox,oy;boolean moving;public boolean onTouch(View v,android.view.MotionEvent e){if(e.getAction()==0){sx=e.getRawX();sy=e.getRawY();ox=lp.leftMargin;oy=lp.topMargin;b.setScaleX(.88f);b.setScaleY(.88f);b.setBackgroundColor(0xff397bb0);return true;}if(e.getAction()==2&&editing){float dx=e.getRawX()-sx,dy=e.getRawY()-sy;if(Math.abs(dx)+Math.abs(dy)>8)moving=true;lp.leftMargin=(int)(ox+dx);lp.topMargin=(int)(oy+dy);b.setLayoutParams(lp);return true;}if(e.getAction()==1||e.getAction()==3){b.setScaleX(1);b.setScaleY(1);b.setBackground(makeBg());if(menu){showSettings();}else if(!editing&&!moving){float[] xy=new float[2];b.getLocationOnScreen(xy);tapMapped(action,xy[0]+b.getWidth()/2f,xy[1]+b.getHeight()/2f);}moving=false;return true;}return true;}});
    }
    private void showSettings(){
        final PopupWindow pop=new PopupWindow(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(14),dp(10),dp(14),dp(10));box.setBackgroundColor(0xee171d2a);
        TextView title=new TextView(this);title.setText("Controle PS2 • ajustes");title.setTextColor(Color.WHITE);title.setTextSize(17);box.addView(title);
        Button edit=new Button(this);edit.setText(editing?"Concluir edição":"Editar / mover botões");edit.setOnClickListener(v->{editing=!editing;edit.setText(editing?"Concluir edição":"Editar / mover botões");Toast.makeText(this,editing?"Arraste os botões para reposicionar":"Edição concluída",Toast.LENGTH_SHORT).show();});box.addView(edit);
        TextView label=new TextView(this);label.setText("Transparência");label.setTextColor(Color.WHITE);box.addView(label);
        SeekBar seek=new SeekBar(this);seek.setMax(100);seek.setProgress((int)(alpha*100));seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int value,boolean user){alpha=value/100f;for(int i=0;i<layer.getChildCount();i++)if(layer.getChildAt(i)!=null)layer.getChildAt(i).setAlpha(alpha);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});box.addView(seek);
        Button done=new Button(this);done.setText("Fechar ajustes");done.setOnClickListener(v->pop.dismiss());box.addView(done);
        pop.setContentView(box);pop.setWidth(dp(300));pop.setHeight(-2);pop.setFocusable(true);pop.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));try{pop.showAtLocation(layer,Gravity.CENTER,0,0);}catch(Exception ignored){}
    }
    private android.graphics.drawable.GradientDrawable makeBg(){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(0xcc263246);d.setCornerRadius(dp(30));d.setStroke(dp(2),0x99ffffff);return d;}
    static void tapMapped(int index){if(instance==null||instance.layer==null)return;for(int i=0;i<instance.layer.getChildCount();i++){View v=instance.layer.getChildAt(i);if(v.getTag() instanceof Integer && ((Integer)v.getTag())==index){float[] xy=new float[2];v.getLocationOnScreen(xy);tapMapped(index,xy[0]+v.getWidth()/2f,xy[1]+v.getHeight()/2f);return;}}}
    static void tapMapped(int index,float x,float y){if(ControllerAccessibilityService.instance!=null)ControllerAccessibilityService.instance.tap(x,y);}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    @Override public void onDestroy(){try{wm.removeView(layer);}catch(Exception ignored){}instance=null;super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
